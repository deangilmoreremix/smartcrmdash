import React from 'react';
import RevenueSharingDashboard from '@/components/billing/RevenueSharingDashboard';

export default function RevenueSharingPage() {
  return <RevenueSharingDashboard />;
}