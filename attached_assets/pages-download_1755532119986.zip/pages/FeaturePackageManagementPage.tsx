import React from 'react';
import FeaturePackageManager from '@/components/packages/FeaturePackageManager';

export default function FeaturePackageManagementPage() {
  return <FeaturePackageManager />;
}