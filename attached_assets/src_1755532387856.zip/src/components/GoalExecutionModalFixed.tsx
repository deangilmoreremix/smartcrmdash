import GoalExecutionModal from './GoalExecutionModalNew';
export default GoalExecutionModal;