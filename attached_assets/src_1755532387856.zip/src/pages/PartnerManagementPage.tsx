import React from 'react';
import PartnerManagement from '@/components/whitelabel/PartnerManagement';

export default function PartnerManagementPage() {
  return <PartnerManagement />;
}